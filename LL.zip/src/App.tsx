import { Map } from './components/map/Map'
import './styles/normalize.css'

function App() {
  return (
    <>
      <Map />
    </>
  )
}

export default App
