# **Documento do Projeto - LocaLista**

O LocaLista é um app simples para ajudar pessoas a encontrar imóveis com base em reviews de outros usuários. A ideia é permitir que o usuário busque por cidade, bairro ou endereço, veja avaliações detalhadas (rating e comentários) e localize os imóveis em um mapa. O foco é uma interface limpa, funcional e fácil de usar, com filtros úteis e informações confiáveis.

---

## **0. Pré-requisitos**

- [x] Appwrite
- [x] Node.js 18+
- [x] Git
- [x] Zed/VSCodium + Prettier
- [x] Bun

## **1. Funcionalidades**

Desenvolver um web app onde usuários:

- Pesquisem reviews por **cidade**
- Visualizem um **pin único** no centro do município
- Filtrem reviews por **bairro ou rua** diretamente no modal
- Cadastre sua própria review
- Pesquisar cidades e bairros primeiro no Appwrite
- Se não encontrado cidade e bairro no Appwrite, pesquisar no Nominatim e adicionar no Appwrite

---

## **2. Fluxo Principal**

```mermaid
flowchart TD
  A[Página Inicial] --> B[Campo de busca: "Digite uma cidade"]
  B --> C[Mapa mostra pin no centro da cidade]
  C --> D[Clique no pin abre modal]
  D --> E[Campo de busca: "Filtrar por bairro/rua"]
  E --> F[Lista dinâmica de reviews]
```

---

## **3. Tecnologias**

| Categoria | Tecnologias Escolhidas   | Justificativa                  |
| --------- | ------------------------ | ------------------------------ |
| Frontend  | React + TypeScript + Bun | Tipagem estática + componentes |
| Mapas     | Leaflet + OpenStreetMap  | Open-source + leve             |
| Backend   | Appwrite Cloud           | Autenticação + DB pronto       |
| Busca     | Nominatim                | Busca de endereços             |
| UI        | Styled Components        | Controle total sobre estilos   |
| Fonte     | Manrope                  | Google Fonts                   |
| Deploy    | Surge.sh                 | Open-source sempre             |

---

## **4. Modelo de Dados**

reviews (TODOS OBRIGATÓRIOS)
| Campo | Tipo |
|----------------|--------|
| cityId | string |
| neighborhoodId | string |
| street | string |
| number | number |
| rating | number |
| commentary | string |
| userId | string |

cities (TODOS OBRIGATÓRIOS)
| Campo | Tipo |
|-------|--------|
| name | string U |
| lat | float |
| lon | float |

neighborhoods (TODOS OBRIGATÓRIOS)
| Campo | Tipo |
|------------|--------|
| name | string U |
| cityId | string |

---

## **5. Checklist de Implementação**

- Dia 1
  - [x] Setup do projeto React + TypeScript
  - [x] Configuração do Appwrite Cloud (Database + Auth)
  - [x] Telas de login/cadastro/recuperação com React Hook Form
  - [x] Roteamento básico
- Dia 2
  - [x] Integração do Leaflet (Mapa base + controles)
  - [x] Lógica de centralização por cidade
  - [x] Pin único com tooltip ao passar o mouse e evento de clique
  - [x] Modal de reviews com busca interna
- Dia 3
  - [x] Formulário de novo review com validação
  - [x] Integração com API do Appwrite
  - [ ] Polimento UI e Responsividade mobile básica
  - [ ] Deploy (Surge.sh + Appwrite)

---
