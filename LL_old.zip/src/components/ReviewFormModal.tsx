import { useState } from 'react';
import styled from 'styled-components';
import { databases, DATABASE_ID, COLLECTIONS } from '../services/appwrite';
import { ID } from 'appwrite';

interface ReviewFormModalProps {
  userId: string;
  onClose: () => void;
}

const ReviewFormModal: React.FC<ReviewFormModalProps> = ({ userId, onClose }) => {
  const [review, setReview] = useState({
    cityId: '',
    neighborhoodId: '',
    street: '',
    number: 0,
    rating: 0,
    commentary: '',
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await databases.createDocument(DATABASE_ID, COLLECTIONS.REVIEWS, ID.unique(), {
        cityId: review.cityId,
        neighborhoodId: review.neighborhoodId,
        street: review.street,
        number: review.number,
        rating: review.rating,
        commentary: review.commentary,
        userId,
      });
      setReview({
        cityId: '',
        neighborhoodId: '',
        street: '',
        number: 0,
        rating: 0,
        commentary: '',
      });
      onClose();
    } catch (err: any) {
      setError('Erro ao criar review: ' + err.message);
    }
  };

  return (
    <ModalOverlay>
      <ModalContent>
        <ModalHeader>
          <h2>Nova Review</h2>
          <CloseButton onClick={onClose}>×</CloseButton>
        </ModalHeader>
        {error && <Error>{error}</Error>}
        <Form onSubmit={handleSubmit}>
          <Input
            type="text"
            placeholder="City ID"
            value={review.cityId}
            onChange={(e) => setReview({ ...review, cityId: e.target.value })}
          />
          <Input
            type="text"
            placeholder="Neighborhood ID"
            value={review.neighborhoodId}
            onChange={(e) => setReview({ ...review, neighborhoodId: e.target.value })}
          />
          <Input
            type="text"
            placeholder="Rua"
            value={review.street}
            onChange={(e) => setReview({ ...review, street: e.target.value })}
          />
          <Input
            type="number"
            placeholder="Número"
            value={review.number}
            onChange={(e) => setReview({ ...review, number: parseInt(e.target.value) })}
          />
          <Input
            type="number"
            placeholder="Rating (0-10)"
            value={review.rating}
            onChange={(e) => setReview({ ...review, rating: parseInt(e.target.value) })}
            min="0"
            max="10"
          />
          <Textarea
            placeholder="Comentário"
            value={review.commentary}
            onChange={(e) => setReview({ ...review, commentary: e.target.value })}
          />
          <Button type="submit">Enviar Review</Button>
        </Form>
      </ModalContent>
    </ModalOverlay>
  );
};

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-family: 'Manrope', sans-serif;
`;

const Textarea = styled.textarea`
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-family: 'Manrope', sans-serif;
  min-height: 100px;
`;

const Button = styled.button`
  padding: 10px 20px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-family: 'Manrope', sans-serif;

  &:hover {
    background: #0056b3;
  }
`;

const Error = styled.div`
  color: red;
  margin-bottom: 10px;
`;

export default ReviewFormModal;