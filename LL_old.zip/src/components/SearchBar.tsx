import styled from 'styled-components';
import { SearchIcon } from '../assets/SearchIcon';

interface NominatimResult {
  place_id: string;
  display_name: string;
  lat: string;
  lon: string;
  name?: string
  address: {
    city?: string;
    city_district?: string;
    town?: string;
    village?: string;
    suburb?: string;
    neighbourhood?: string;
    road?: string;
    state?: string;
    country?: string;
    municipality?: string;
  };
}

interface SearchBarProps {
  searchTerm: string;
  onSearch: (term: string) => void;
  onChange: (term: string) => void;
  results: NominatimResult[];
  onSelectResult: (result: NominatimResult) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, onSearch, onChange, results, onSelectResult }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  return (
    <SearchContainer>
      {results.length > 0 && (
        <ResultsList role="listbox">
          {results
            .filter((result) => {
              const term = searchTerm.toLowerCase();
              const matchesSearch =
                result.display_name.toLowerCase().includes(term) ||
                Object.values(result.address)
                  .filter(Boolean)
                  .some((value) => value.toLowerCase().includes(term));
              return matchesSearch;
            })
            .map((result) => {
              const name = result.name;
              const city = result.address.city;
              const suburb = result.address.suburb || result.address.neighbourhood;
              const road = result.address.road;
              const state = result.address.state;
              const country = result.address.country;
              const primaryName = road || suburb || city || result.display_name.split(',')[0];
              const details = [city, state, country].filter(Boolean).join(', ');
              const displayName = details ? `${primaryName} - ${details}` : primaryName;

              return (
                <ResultItem
                  key={result.place_id}
                  onClick={() => onSelectResult(result)}
                  role="option"
                  aria-selected="false"
                >
                  <PrimaryName>{name}</PrimaryName>
                  {details && <Details>{details}</Details>}
                </ResultItem>
              );
            })}
        </ResultsList>
      )}
      <Form onSubmit={handleSubmit}>
        <SearchInput
          type="text"
          placeholder="Buscar cidade, bairro ou rua"
          value={searchTerm}
          onChange={(e) => onChange(e.target.value)}
        />
        <SearchButton type="submit" aria-label="Buscar">
          <SearchIcon />
        </SearchButton>
      </Form>
    </SearchContainer>
  );
};

const SearchContainer = styled.div`
  position: fixed;
  bottom: 2rem;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 30rem;
  z-index: 1000;
  background: var(--bg1);
  padding: 1rem;
  border-radius: 1rem;
  box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);

  @media (max-width: 720px) {
    bottom: 0;
    left: 0;
    max-width: 100%;
    padding: 0.75rem 0.5rem 1.5rem;
    border-radius: 0;
    box-shadow: 0 -1px 2px rgba(0, 0, 0, 0.1);
  }
`;

const Form = styled.form`
  overflow: hidden;
  display: flex;
  align-items: center;
  height: 3.5rem;
  border: 2px solid var(--comp);
  border-radius: 0.75rem;
  background-color: var(--bg2);
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 1rem;
  color: var(--text);
  background-color: transparent;
  font-weight: 500;
  border: none;
  outline: none;
`;

const SearchButton = styled.button`
  height: 100%;
  padding: 0.5rem 1rem 0.5rem 0.25rem;
  background: transparent;
  border: none;
  cursor: pointer;
`;

const ResultsList = styled.ul`
  flex: 1;
  list-style: none;
  max-height: 25rem;
  margin: 0 0 10px;
  padding: 0;
  color: var(--text);
  overflow-y: auto;
  background: transparent;
  border-radius: 4px;
  border: solid 2px var(--comp);
`;

const ResultItem = styled.li`
  display: flex;
  flex-direction: column;
  padding: 10px;
  cursor: pointer;

  &:hover {
    background: var(--primary);
  }
`;

const PrimaryName = styled.span`
  font-weight: 600;
  font-size: 1rem;
`;

const Details = styled.span`
  font-size: 0.875rem;
  color: var(--text);
  opacity: 0.7;
`;

export default SearchBar;