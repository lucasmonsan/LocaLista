import styled from 'styled-components';

interface Review {
  $id: string;
  neighborhoodName: string;
  street: string;
  number: number;
  rating: number;
  commentary: string;
  userId: string;
}

interface ReviewsModalProps {
  cityName: string;
  reviews: Review[];
  streetSearchTerm: string;
  neighborhoodSearchTerm: string;
  onStreetSearch: (term: string) => void;
  onNeighborhoodSearch: (term: string) => void;
  onClose: () => void;
}

const ReviewsModal: React.FC<ReviewsModalProps> = ({
  cityName,
  reviews,
  streetSearchTerm,
  neighborhoodSearchTerm,
  onStreetSearch,
  onNeighborhoodSearch,
  onClose,
}) => {
  return (
    <ModalOverlay>
      <ModalContent>
        <ModalHeader>
          <h2>Reviews de {cityName}</h2>
          <CloseButton onClick={onClose}>×</CloseButton>
        </ModalHeader>
        <SearchInput
          type="text"
          placeholder="Filtrar por rua"
          value={streetSearchTerm}
          onChange={(e) => onStreetSearch(e.target.value)}
        />
        <SearchInput
          type="text"
          placeholder="Filtrar por bairro"
          value={neighborhoodSearchTerm}
          onChange={(e) => onNeighborhoodSearch(e.target.value)}
        />
        <ReviewList>
          {reviews.length > 0 ? (
            reviews.map((review) => (
              <ReviewItem key={review.$id}>
                <p><strong>Bairro:</strong> {review.neighborhoodName}</p>
                <p><strong>Rua:</strong> {review.street}, {review.number}</p>
                <p><strong>Rating:</strong> {review.rating}/10</p>
                <p><strong>Comentário:</strong> {review.commentary}</p>
                <p><strong>Usuário:</strong> {review.userId}</p>
              </ReviewItem>
            ))
          ) : (
            <p>Nenhuma review encontrada.</p>
          )}
        </ReviewList>
      </ModalContent>
    </ModalOverlay>
  );
};

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: white;
  padding: 20px;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-family: 'Manrope', sans-serif;
`;

const ReviewList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const ReviewItem = styled.div`
  border: 1px solid #eee;
  padding: 10px;
  border-radius: 4px;
`;

export default ReviewsModal;