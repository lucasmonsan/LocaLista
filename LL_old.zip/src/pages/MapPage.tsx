import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Query } from 'appwrite';
import styled from 'styled-components';
import 'leaflet/dist/leaflet.css';
import { account, databases, DATABASE_ID, COLLECTIONS } from '../services/appwrite';
import { useNavigate } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import ReviewsModal from '../components/ReviewsModal';
import ReviewFormModal from '../components/ReviewFormModal';

interface City {
  $id: string;
  name: string;
  lat: number;
  lon: number;
}

interface Neighborhood {
  $id: string;
  name: string;
  cityId: string;
}

interface Review {
  $id: string;
  cityId: string;
  neighborhoodId: string;
  street: string;
  number: number;
  rating: number;
  commentary: string;
  userId: string;
}

interface ReviewWithNeighborhood extends Review {
  neighborhoodName: string;
}

interface NominatimResult {
  place_id: string;
  display_name: string;
  lat: string;
  lon: string;
  address: {
    city?: string;
    town?: string;
    village?: string;
    suburb?: string;
    neighbourhood?: string;
    road?: string;
    country?: string;
  };
}

const MapPage = () => {
  const [city, setCity] = useState<City | null>(null);
  const [cities, setCities] = useState<City[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<NominatimResult[]>([]);
  const [neighborhoods, setNeighborhoods] = useState<Map<string, string>>(new Map());
  const [reviews, setReviews] = useState<ReviewWithNeighborhood[]>([]);
  const [filteredReviews, setFilteredReviews] = useState<ReviewWithNeighborhood[]>([]);
  const [streetSearchTerm, setStreetSearchTerm] = useState('');
  const [neighborhoodSearchTerm, setNeighborhoodSearchTerm] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();

  // Verificar usuário logado
  useEffect(() => {
    const checkUser = async () => {
      try {
        const response = await account.get();
        setUser(response);
      } catch (err) {
        setUser(null);
      }
    };
    checkUser();
  }, []);

  // Buscar cidades do Appwrite
  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await databases.listDocuments(DATABASE_ID, COLLECTIONS.CITIES);
        const mappedCities: City[] = response.documents.map((doc) => ({
          $id: doc.$id,
          name: doc.name as string,
          lat: doc.lat as number,
          lon: doc.lon as number,
        }));
        setCities(mappedCities);
        const defaultCity = mappedCities.find((c) => c.$id === '6839f3bb00129f1158eb');
        if (defaultCity) setCity(defaultCity);
      } catch (err: any) {
        setError('Erro ao buscar cidades: ' + err.message);
      }
    };
    fetchCities();
  }, []);

  // Buscar bairros
  useEffect(() => {
    if (!city) return;
    const fetchNeighborhoods = async () => {
      try {
        const response = await databases.listDocuments(
          DATABASE_ID,
          COLLECTIONS.NEIGHBORHOODS,
          [Query.equal('cityId', city.$id)]
        );
        const neighborhoodMap = new Map<string, string>();
        response.documents.forEach((doc: any) => {
          neighborhoodMap.set(doc.$id, doc.name);
        });
        setNeighborhoods(neighborhoodMap);
      } catch (err: any) {
        setError('Erro ao buscar bairros: ' + err.message);
      }
    };
    fetchNeighborhoods();
  }, [city]);

  // Buscar reviews
  useEffect(() => {
    if (!city || neighborhoods.size === 0) return;
    const fetchReviews = async () => {
      try {
        const response = await databases.listDocuments(
          DATABASE_ID,
          COLLECTIONS.REVIEWS,
          [Query.equal('cityId', city.$id)]
        );
        const mappedReviews: ReviewWithNeighborhood[] = response.documents.map((doc) => ({
          $id: doc.$id,
          cityId: doc.cityId,
          neighborhoodId: doc.neighborhoodId,
          neighborhoodName: neighborhoods.get(doc.neighborhoodId) || 'Desconhecido',
          street: doc.street,
          number: doc.number,
          rating: doc.rating,
          commentary: doc.commentary,
          userId: doc.userId,
        }));
        setReviews(mappedReviews);
        setFilteredReviews(mappedReviews);
      } catch (err: any) {
        setError('Erro ao buscar reviews: ' + err.message);
      }
    };
    fetchReviews();
  }, [city, neighborhoods]);

  // Filtrar reviews
  useEffect(() => {
    if (!streetSearchTerm && !neighborhoodSearchTerm) {
      setFilteredReviews(reviews);
      return;
    }
    const fetchFilteredReviews = async () => {
      try {
        let queries = [Query.equal('cityId', city!.$id)];
        if (streetSearchTerm) queries.push(Query.search('street', streetSearchTerm));
        const response = await databases.listDocuments(
          DATABASE_ID,
          COLLECTIONS.REVIEWS,
          queries
        );
        const mappedReviews: ReviewWithNeighborhood[] = response.documents.map((doc) => ({
          $id: doc.$id,
          cityId: doc.cityId,
          neighborhoodId: doc.neighborhoodId,
          neighborhoodName: neighborhoods.get(doc.neighborhoodId) || 'Desconhecido',
          street: doc.street,
          number: doc.number,
          rating: doc.rating,
          commentary: doc.commentary,
          userId: doc.userId,
        }));
        const filtered = mappedReviews.filter((review) =>
          neighborhoodSearchTerm
            ? review.neighborhoodName.toLowerCase().includes(neighborhoodSearchTerm.toLowerCase())
            : true
        );
        setFilteredReviews(filtered);
      } catch (err: any) {
        setError('Erro ao filtrar reviews: ' + err.message);
      }
    };
    if (city) fetchFilteredReviews();
  }, [streetSearchTerm, neighborhoodSearchTerm, city, reviews, neighborhoods]);

  const handlePinClick = () => {
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
    setStreetSearchTerm('');
    setNeighborhoodSearchTerm('');
  };

  const handleSearch = async (term: string) => {
    if (!term) {
      setSearchResults([]);
      return;
    }
    try {
      // Busca por ID no Appwrite
      const idFiltered = cities.filter((c) => c.$id.toLowerCase().includes(term.toLowerCase()));
      if (idFiltered.length > 0) {
        setCity(idFiltered[0]);
        setSearchResults([]);
        return;
      }

      // Busca na Nominatim
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(term)}&format=json&limit=15&addressdetails=1`
      );
      const results: NominatimResult[] = await response.json();
      setSearchResults(results);
    } catch (err: any) {
      setError('Erro ao buscar na Nominatim: ' + err.message);
    }
  };

  const handleSelectResult = (result: NominatimResult) => {
    const cityName = result.address.city || result.address.town || result.address.village;
    const appwriteCity = cities.find(
      (c) => c.name.toLowerCase() === cityName?.toLowerCase()
    );

    if (appwriteCity) {
      // Cidade existe no Appwrite, usar suas coordenadas
      setCity(appwriteCity);
    } else {
      // Cidade não está no Appwrite, usar coordenadas da Nominatim
      setCity({
        $id: '',
        name: cityName || result.display_name.split(',')[0],
        lat: parseFloat(result.lat),
        lon: parseFloat(result.lon),
      });
    }
    setSearchResults([]);
    setSearchTerm('');
  };

  // Componente para recentralizar o mapa
  const MapUpdater = ({ center }: { center: [number, number] }) => {
    const map = useMap();
    useEffect(() => {
      map.setView(center, 13);
    }, [center, map]);
    return null;
  };

  if (error) {
    return <Error>{error}</Error>;
  }

  if (!city) {
    return <div>Carregando mapa...</div>;
  }

  return (
    <Container>
      <SearchBar
        searchTerm={searchTerm}
        onSearch={handleSearch}
        onChange={setSearchTerm}
        results={searchResults}
        onSelectResult={handleSelectResult}
      />

      <MapContainer
        center={[city.lat, city.lon]}
        zoom={13}
        style={{ height: '100vh', width: '100vw' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <Marker position={[city.lat, city.lon]} eventHandlers={{ click: handlePinClick }}>
          <Popup>{city.name}</Popup>
        </Marker>
        <MapUpdater center={[city.lat, city.lon]} />
      </MapContainer>

      <ButtonContainer>
        {user ? (
          <>
            <Button onClick={() => setReviewModalOpen(true)}>Nova Review</Button>
            <Button onClick={() => account.deleteSession('current').then(() => setUser(null))}>
              Logout
            </Button>
          </>
        ) : (
          <Button onClick={() => navigate('/auth')}>Login</Button>
        )}
      </ButtonContainer>

      {modalOpen && (
        <ReviewsModal
          cityName={city.name}
          reviews={filteredReviews}
          streetSearchTerm={streetSearchTerm}
          neighborhoodSearchTerm={neighborhoodSearchTerm}
          onStreetSearch={setStreetSearchTerm}
          onNeighborhoodSearch={setNeighborhoodSearchTerm}
          onClose={handleCloseModal}
        />
      )}
      {reviewModalOpen && user && (
        <ReviewFormModal userId={user.$id} onClose={() => setReviewModalOpen(false)} />
      )}
    </Container>
  );
};

const Container = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100dvh;
  height: 100dvh;
  max-height: 100dvh;
  width: 100%;
`;

const ButtonContainer = styled.div`
  position: fixed;
  top: 20px;
  right: 20px;
  display: flex;
  gap: 10px;
  z-index: 1000;
`;

const Button = styled.button`
  padding: 10px 20px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-family: 'Manrope', sans-serif;

  &:hover {
    background: #0056b3;
  }
`;

const Error = styled.div`
  color: red;
  padding: 20px;
`;

export default MapPage;