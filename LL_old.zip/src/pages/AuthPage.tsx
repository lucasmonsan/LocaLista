import { useState, useEffect } from 'react';
import { account } from '../services/appwrite';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { ID } from 'appwrite';
import ReviewFormModal from '../components/ReviewFormModal';

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const navigate = useNavigate();

  // Restaurar sessão
  useEffect(() => {
    const checkSession = async () => {
      try {
        const user = await account.get();
        setUser(user);
        navigate('/map');
      } catch (err) {
        setUser(null);
      }
    };
    checkSession();
  }, [navigate]);

  // Login
  const handleLogin = async () => {
    try {
      await account.createEmailPasswordSession(email, password);
      const user = await account.get();
      setUser(user);
      setError(null);
      navigate('/map');
    } catch (err: any) {
      setError('Erro no login: ' + err.message);
    }
  };

  // Cadastro
  const handleRegister = async () => {
    try {
      await account.create(ID.unique(), email, password);
      await handleLogin();
    } catch (err: any) {
      setError('Erro no cadastro: ' + err.message);
    }
  };

  // Logout
  const handleLogout = async () => {
    try {
      await account.deleteSession('current');
      setUser(null);
      setEmail('');
      setPassword('');
      setError(null);
      navigate('/auth');
    } catch (err: any) {
      setError('Erro no logout: ' + err.message);
    }
  };

  if (!user) {
    return (
      <Container>
        <h1>{isLogin ? 'Login' : 'Cadastro'}</h1>
        {error && <Error>{error}</Error>}
        <Input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Input
          type="password"
          placeholder="Senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Button onClick={isLogin ? handleLogin : handleRegister}>
          {isLogin ? 'Entrar' : 'Cadastrar'}
        </Button>
        <ToggleButton onClick={() => setIsLogin(!isLogin)}>
          {isLogin ? 'Criar conta' : 'Já tenho conta'}
        </ToggleButton>
      </Container>
    );
  }

  return (
    <Container>
      <h1>Bem-vindo, {user.email}</h1>
      {error && <Error>{error}</Error>}
      <Button onClick={() => setModalOpen(true)}>Nova Review</Button>
      <Button onClick={handleLogout}>Logout</Button>
      {modalOpen && <ReviewFormModal userId={user.$id} onClose={() => setModalOpen(false)} />}
    </Container>
  );
};

const Container = styled.div`
  padding: 20px;
  max-width: 400px;
  margin: 0 auto;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-family: 'Manrope', sans-serif;
`;

const Button = styled.button`
  padding: 10px 20px;
  margin-right: 10px;
  margin-bottom: 10px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-family: 'Manrope', sans-serif;

  &:hover {
    background: #0056b3;
  }
`;

const ToggleButton = styled.button`
  padding: 10px 20px;
  margin-bottom: 10px;
  background: #6c757d;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-family: 'Manrope', sans-serif;

  &:hover {
    background: #5a6268;
  }
`;

const Error = styled.div`
  color: red;
  margin-bottom: 10px;
`;

export default AuthPage;